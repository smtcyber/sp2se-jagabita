<div class="col-lg-12">
		<div class='panel-heading'></i></div>
		  <section id="contact" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2>Contact Us</h2>
          <p><h3>Secretariat Office - Dinas Kearsipan dan Perpustakaan Kabupaten Cirebon</h3></p>
        </div>

        <div class="row contact-info">

          <div class="col-md-4">
            <div class="contact-address">
              <i class="ion-ios-location-outline"></i>
              <h3>Address</h3>
              <address>Jalan Sunan Kalijaga Nomor. 1, Kode Pos. 45611</address>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-phone">
              <i class="ion-ios-telephone-outline"></i>
              <h3>Phone Number</h3>
              <p><a href="tel:(0231) 8330595">(0231) 8330595</a></p>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-email">
              <i class="ion-ios-email-outline"></i>
              <h3>Email</h3>
              <p><a href="mailto:info@example.com">disarpus@cirebonkab.go.id</a></p>
            </div>
          </div>

        </div>
      </div>

      </div>
    </section>
</div><!-- /.col-lg-12 -->