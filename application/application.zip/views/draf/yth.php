<table border="0" align="center" align="justify" style="line-height: 25px; font-size: 18px; font-family: times;">
	<tr>
		<td width="30">&nbsp;</td>
		<td width="620" align="justify">Yang  Bertanda  tangan  di  bawah  ini  Kepala Desa  <?php echo ucwords(strtolower($tampil->kelurahan)) ?>  Kecamatan  <?php echo ucwords(strtolower($tampil->kecamatan)) ?>  Kabupaten  <?php echo ucwords(strtolower($tampil->kabupaten)) ?>, menerangkan dengan sesungguhnya bahwa :</td>
		<td width="20">&nbsp;</td>
	</tr>
</table>