<table border="0" align="justify" style="line-height: 25px; font-size: 17px; font-family: times;">
	<tr>
		<td width="40">&nbsp;</td>
		<td width="620" align="justify" style="text-indent: 3em;">Yang  Bertanda  tangan  di  bawah  ini  Kepala Desa  <?php echo ucwords(strtolower($data->kelurahan)) ?>  Kecamatan  <?php echo ucwords(strtolower($data->kecamatan)) ?>  Kabupaten  <?php echo ucwords(strtolower($data->kabupaten)) ?>, menerangkan dengan sesungguhnya bahwa :</td>
		<td width="20">&nbsp;</td>
	</tr>
</table>
<br>