<div class="cd-full-width" style="margin-top: 50px; margin-left: 15px;" id="pageone">
                        <div class="container-fluid js-tm-page-content">
                            <div class="tm-img-gallery-container" style="margin-top: 10px;">    

                                    
                                    <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" id="pageone" style="width: 260px">
                                            <a target="_blank" href="https://bogorpbb.smtcyber.com/layanan">
                                            <div style="background:#D2691E; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets_webdes/images/epbb_new.png'); ?>" width="100" height="125"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                    <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" id="pageone" style="width: 260px">
                                            <a target="_blank" href="https://bumdes.smtcyber.com/">
                                            <div style="background:#ADFF2F; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets_webdes/images/ebumdes_new1.png'); ?>" width="100" height="120"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                    <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" id="pageone" style="width: 260px">
                                            <a target="_blank" href="https://spob.smtcyber.com//c_ppob">
                                            <div style="background:#32CD32; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets_webdes/images/ppob_new.png'); ?>" width="100" height="120"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                    <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" id="pageone" style="width: 260px">
                                            <a target="_blank" href="https://e-umkm.com/">
                                            <div style="background:#9ACD32; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets_webdes/images/eumkm_new1.png'); ?>" width="120" height="75"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                    <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" id="pageone" style="width: 260px">
                                            <a target="_blank" href="https://jagabita.smtcyber.com//webdes">
                                            <div style="background:#FFD700; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets_webdes/images/desa_new1.png'); ?>" width="120" height="80"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>



                                    <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" id="pageone" style="width: 325px" data-toggle="modal" data-target="#tesModal">
                                            <a href="<?php echo site_url('c_sku/panel_sku');?>">
                                            <div style="background:#C54D4F; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/014-shop copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN<br>USAHA<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_skck/panel_skck');?>">
                                            <div style="background:#4463C5; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/police.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN CATATAN KEPOLISIAN<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_kehilangan/panel_kehilangan');?>">
                                            <div style="background:#B0A614; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/question-speech-bubble copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN KEHILANGAN<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_haji/panel_haji');?>">
                                            <div style="background:#9967A7; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/haji.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN DOMISILI HAJI<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>
                                        
                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_belum_bekerja/panel_belum_bekerja');?>">
                                            <div style="background:#355c7d; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/belum-bekerja.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN BELUM BEKERJA<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px" id="pagetwo">
                                             
                                            <a href="<?php echo site_url('c_yatim/panel_yatim');?>">
                                            <div style="background:#e66f51; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/yatim.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN <br> YATIM<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_ghoib/panel_ghoib');?>">
                                            <div style="background:#018f81; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/ghoib.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN <br> GHOIB<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            <a href="<?php echo site_url('c_domisili_tinggal/panel_domtinggal');?>">
                                            <div style="background:#923DC3; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/map.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN DOMISILI TINGGAL<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_pekerjaan/panel_pekerjaan');?>">
                                            <div style="background:#ff3158; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/pekerjaan.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT PERNYATAAN <br> PEKERJAAN<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_penghasilan/panel_penghasilan');?>">
                                            <div style="background:#8E8E8E; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/box.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN PENGHASILAN<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_keterangan_jalan/panel_keterangan_jalan');?>">
                                            <div style="background:#07A3DB; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/mabur.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN PERJALANAN<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_lain_lain/panel_lain_lain');?>">
                                            <div style="background:#7DBDA6; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/lain.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN LAIN-LAIN<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_ktp_sementara/panel_ktp_sementara');?>">
                                            <div style="background:#9021C0; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/041-cheque copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN KTP SEMENTARA<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px" id="pagethree">
                                            
                                            <a href="<?php echo site_url('c_belum_memiliki_rumah/panel_belum_memiliki_rumah');?>">
                                            <div style="background:#C54D4F; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/007-house copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN BELUM MEMILIKI RUMAH<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_pernyataan/panel_pernyataan');?>">
                                            <div style="background:#4BA630; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/umum.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT PERNYATAAN UMUM<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_bp_ktp/panel_bp_ktp');?>">
                                            <div style="background:#83A647; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/010-contract copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN BELUM MEMILIKI KTP<br><h6 style="color: white; margin-top: 5px;">Print Out</h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_domlembaga/panel_domlembaga');?>">
                                            <div style="background:#3359D1; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/010-certificate-1 copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN DOMISILI LEMBAGA</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>
                                        
                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_kepemilikan_tanah/panel_kepemilikan_tanah');?>">
                                            <div style="background:#92560A; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/032-placeholder copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN TIDAK SENGKETA<br><h6 style="color: white; margin-top: 5px;"></h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            <a href="<?php echo site_url('c_domisili_usaha/panel_domusaha');?>">
                                            <div style="background:#489C51; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/004-placeholder copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN DOMISILI USAHA<br><h6 style="color: white; margin-top: 5px;"></h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>                    

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            <a href="<?php echo site_url('c_ramai/panel_ramai');?>">
                                            <div style="background:#C06F1F; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/005-megaphone copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN IZIN RAMAI</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_andon_nikah/panel_andon_nikah');?>">
                                            <div style="background:#D815A0; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/024-groom copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN ANDON NIKAH</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_daftar_nikah/panel_daftar_nikah');?>">
                                            <div style="background:#09CCB7; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/001-wedding-rings copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN DAFTAR NIKAH</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px" >
                                            
                                            <a href="<?php echo site_url('c_sktm/panel_sktm');?>">
                                            <div style="background:#7A7A7A; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/018-piggy-bank copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN TIDAK MAMPU</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_kelahiran/panel_kelahiran');?>">
                                            <div style="background:#F46D06; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/029-boy copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN KELAHIRAN</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_kematian/panel_kematian');?>">
                                            <div style="background:#966F27; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/grave copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN KEMATIAN</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_pindah_datang/panel_pindah_datang');?>">
                                            <div style="background:#139823; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/deliver.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN PINDAH DATANG</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px" id="pagefour">
                                            
                                            <a href="<?php echo site_url('c_kenal_lahir/panel_kenal_lahir');?>">
                                            <div style="background:#944770; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/kenal.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN KENAL LAHIR</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_kartu_keluarga/panel_kartu_keluarga');?>">
                                            <div style="background:#9967A7; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/family-group-of-three.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN KARTU KELUARGA</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_ahli_waris/panel_ahli_waris');?>">
                                            <div style="background:#B34B4D; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/family copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN AHLI WARIS</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_pendaftaran_ktp/panel_pendaftaran_ktp');?>">
                                            <div style="background:#65509B; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/008-id-card copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT PENDAFTARAN KTP</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_skbn/panel_skbn');?>">
                                            <div style="background:#B58817; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/025-engagement-ring copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN BELUM MENIKAH / JANDA/DUDA</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>


                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_gadai/panel_gadai');?>">
                                            <div style="background:#8E8E8E; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/box.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT PERNYATAAN GADAI</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_keterangan_tanah/panel_keterangan_tanah');?>">
                                            <div style="background:#537742; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/018-map copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN TANAH</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_beda_identitas/panel_beda_identitas');?>">
                                            <div style="background:#872F2F; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/beda.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN BEDA IDENTITAS</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_domsekolah/panel_domsekolah');?>">
                                            <div style="background:#619645; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/010-certificate-1 copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN DOMISILI SEKOLAH</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_domlembaga/panel_domlembaga');?>">
                                            <div style="background:#3359D1; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/010-certificate-1 copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN DOMISILI LEMBAGA</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_domperusahaan/panel_domperusahaan');?>">
                                            <div style="background:#7721B7; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/010-certificate-1 copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT KETERANGAN DOMISILI PERUSAHAAN</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            
                                            <a href="<?php echo site_url('c_bersama/panel_bersama');?>">
                                            <div style="background:#CD7709; height: 240px;">
                                                <table border="0" align="center">
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220"><img src="<?php echo base_url('assets/icon/010-certificate-1 copy.png'); ?>" width="100" height="100"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" width="220" style="color: white; line-height: 22px; font-weight: bold;">SURAT PERNYATAAN BERSAMA</td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </a>
                                            <br>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box" style="width: 325px">
                                            <a href="<?php echo site_url('c_tkk1/panel_tkk1');?>">
                                                <div style="background:#9967A7; height: 240px;">
                                                    <table border="0" align="center">
                                                        <tr>
                                                            <td>&nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td align="center" width="220"><img
                                                                    src="<?php echo base_url('assets/icon/family-group-of-three.png'); ?>"
                                                                    width="100" height="100"></td>
                                                        </tr>
                                                        <tr>
                                                            <td>&nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td align="center" width="220"
                                                                style="color: white; line-height: 22px; font-weight: bold;">SURAT PENGANTAR KARTU KELUARGA
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>&nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </a>
                                            <br>
                                        </div>
                                  
                    </div>

            </div>                                                    
</div>        