<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="<?php echo base_url('assets/images/SMT.png'); ?>">
<title>Cetak Model N-2</title>
<style type="text/css">
body,td,th {
	font-size: 18px;
	font-family: Times;
}
.table {
	border: thin;
}
.table td,th {
	padding-top: 10px;
	padding-bottom: 10px;
	font-size: 18px;
}
.table th {
	background-color: #4e73df;
}
h1,h2,h3,h4,h5 {
	margin: -10px;
}
h1 {
	margin-top: -10px;
	margin-bottom: -30px;
}
</style>

</head>
<body>
<table align="center" cellpadding="0" cellspacing="0" width="100%" border="0">
</table>
<br>
<table border="0" width="100" align="left" style="font-size: 15px;">
	<tr>
		<td align="left" width="800" style="font-size: 10">LAMPIRAN I
<br>KEPUTUSAN DIREKTUR JENDERAL BIMBINGAN MASYARAKAT ISLAM
<br>NOMOR 473 TAHUN 2020
<br>TENTANG
<br>PETUNJUK TEKNIS PELAKSANAAN PENCATATAN PERNIKAHAN</td>
	</tr>
</table>
<table border="0" width="100" align="right">
	<tr>
		<td align="right">Model N2</td>
	</tr>
</table><br><br>
<h4 style="text-align: center; font-family: Times;"><u>FORMULIR PERMOHONAN KEHENDAK NIKAH</u><br></h4>
<br>
<table border="0" align="left" font-size="12">
	<tr>
		<td width="30">&nbsp;</td>
		<td width="350" align="left">Perihal  : Permohonan Kehendak Nikah</td>
		<td width="290" align="right"><?php echo ucwords(strtolower($tampil->kecamatan)) ?>, <?php $tanggal_hari_ini= date('Y-m-d'); echo tgl_indo($tanggal_hari_ini);?></td>
	</tr>
</table><br>
<table border="0" align="left">
	<tr>
		<td width="30">&nbsp;</td>
		<td width="630" align="justify"><br>Kepada Yth.<br>Kepala <b>KUA Kecamatan <?php echo ucwords(strtolower($tampil->kecamatan)) ?></b><br>Di<br><?php echo ucwords(strtolower($tampil->kecamatan)) ?></td>
	</tr>
</table><br>
<table border="0" align="center" style="line-height: 25px;">
	<tr>
		<td width="20">&nbsp;</td>
		<td width="630" align="left">Dengan hormat, kami mengajukan permohonan kehendak nikah untuk atas nama :<br> 
		Calon <?php if($tampil->kelamin == "Laki-Laki"){ echo "Suami"; }else { echo "Istri";}?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <b><?php echo $tampil->nama;?></b> <br> 
		Calon <?php if($tampil->jenis_kelamin_calon == "Laki-Laki"){ echo "Istri"; }else { echo "Suami";}?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <b><?php echo $tampil->nama_calon;?></b> <br> 
		Hari/Tanggal/Jam &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <?php echo $tampil->hari_nikah;?>, <?php echo tgl_indo(date('Y-m-d', strtotime($tampil->tgl_nikah))); ?> Jam <?php echo $tampil->waktu_nikah_mulai;?> WIB<br>
		Maskawin &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <?php echo $tampil->maskawin;?> <br> 
		Tempat Akad Nikah &nbsp;&nbsp;&nbsp;&nbsp;: <?php echo $tampil->tempat_nikah;?>.</td>
	</tr>
</table><br>
<table border="0" align="center">
	<tr>
		<td width="20">&nbsp;</td>
		<td width="630" align="justify">Bersama ini kami lampirkan surat-surat yang diperlukan untuk diperiksa sebagai berikut :</td>
	</tr>
</table><br>
<table border="0" align="center">
	<tr>
		<td width="20">&nbsp;</td>
		<td width="20" align="left">1.</td>
		<td align="left" width="500">Surat Pengantar Perkawinan dari Desa / Kelurahan</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="20" align="left">2.</td>
		<td align="left" width="500"> Persetujuan Calon Mempelai</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="20" align="left">3.</td>
		<td align="left" width="500">Fotocopy KTP</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="20" align="left">4.</td>
		<td align="left" width="500"> Fotocopy Akta Kelahiran</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="20" align="left">5.</td>
		<td align="left" width="500">Fotocopy Kartu Keluarga</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="20" align="left">6.</td>
		<td align="left" width="500">Pas Foto 2 x 3 = 3 lembar berlatar belakang biru</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="20" align="left">7.</td>
		<td align="left" width="500">Surat Izin Orang Tua</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="20" align="left">8.</td>
		<td align="left" width="500">Rekomendasi Nikah</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="20" align="left">9.</td>
		<td align="left" width="500">Surat Kematian</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="20" align="left">10.</td>
		<td align="left" width="500">Dispensasi Pengadilan Agama</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="20" align="left">11.</td>
		<td align="left" width="500">Dispensasi Kecamatan</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="20" align="left">12.</td>
		<td align="left" width="500">Surat Izin Kesatuan/POLRI/TNI</td>
	</tr>
</table><br>
<table border="0" align="center" style="line-height: 25px;">
	<tr>
		<td width="20">&nbsp;</td>
		<td width="630" align="justify">Demikian  permohonan  ini  kami  sampaikan,  kiranya  dapat  diperiksa,  dihadiri  dan  dicatat  sesuai  dengan  ketentuan  perundang-undangan.</td>
	</tr>
</table><br><br>
<table border="0" align="left">
	<tr>
		<td width="20">&nbsp;</td>
		<td align="center" width="230">Diterima tanggal  <?php $tanggal_hari_ini= date('Y-m-d'); echo tgl_indo($tanggal_hari_ini); ?></td>
		<td width="180">&nbsp;</td>
		<td align="center" width="230" colspan="2"></td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td align="center" width="230">Yang menerima,</td>
		<td width="130">&nbsp;</td>
		<td align="center" width="230">&nbsp;</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td align="center" width="180">Kepala KUA/Penghulu/PPN Luar Negeri*)</td>
		<td width="130">&nbsp;</td>
		<td align="center" width="180">Pemohon,</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="210">&nbsp;</td>
		<td width="130">&nbsp;</td>
		<td width="210">&nbsp;</td>
	</tr>
	<tr>
		<td width="30">&nbsp;</td>
		<td width="210">&nbsp;</td>
		<td width="130">&nbsp;</td>
		<td width="210">&nbsp;</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="210">&nbsp;</td>
		<td width="130">&nbsp;</td>
		<td width="210">&nbsp;</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="230" align="center">......................................</td>
		<td width="130">&nbsp;</td>
		<td width="230" align="center"><b><u><?php echo $tampil->nama;?></u></b></td>
	</tr>
</table>
</body>
</html>